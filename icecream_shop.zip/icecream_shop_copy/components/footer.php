<div class="newsletter">
    <div class="content">
        <span>get latest blue sky summer updates</span>
        <h1>subscribe our newsletter</h1>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eius ut qui iure <br>
         voluptate aut atque incidunt ratione tenetur, excepturi fugiat.</p>
        <div class="input-field">
            <input type="email" name="" placeholder="Enter your emial">
            <button class="btn">subscribe</button>
        </div>
        <p>No Ads ,No trails,No commitment</p>
        <div class="box-container">
            <div class="box">
                <div class="box-counter"><p class="counter">5000</p><i class="bxbx-plus"></i></div>
                <h3>Successfully Trained</h3>
                <p>learners and counting</p>
            </div>
            <div class="box">
                <div class="box-counter"><p class="counter">10000</p><i class="bxbx-plus"></i></div>
                <h3>Certification seller</h3>
                <p>online seller</p>
            </div>
        </div>
    </div>
</div>
<footer>
    <div class="content">
        <div class="box">
            <img src="../image/logo-shop.png" alt="" srcset="" class="footer-image">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iure, 
                <br>necessitatibus officia eaque quidem fugit odit.</p>
                <a href="../contact.php" class="btn">contact now</a>
        </div>
        <div class="box">
            <h3>my accounts</h3>
            <a href=""><i class="bx bx-chevron-right"></i>My account</a>
            <a href=""><i class="bx bx-chevron-right"></i>Order History</a>
            <a href=""><i class="bx bx-chevron-right"></i>Wishlist</a>
            <a href=""><i class="bx bx-chevron-right"></i>newsletter</a>
        </div>
        <div class="box">
            <h3>information</h3>
            <a href=""><i class="bx bx-chevron-right"></i>about us</a>
            <a href=""><i class="bx bx-chevron-right"></i>dilivery information</a>
            <a href=""><i class="bx bx-chevron-right"></i>privacy policy</a>
            <a href=""><i class="bx bx-chevron-right"></i>terms & condition</a>
        </div>
        <div class="box">
            <h3>extras</h3>
            <a href=""><i class="bx bx-chevron-right"></i>brands</a>
            <a href=""><i class="bx bx-chevron-right"></i>gift certification</a>
            <a href=""><i class="bx bx-chevron-right"></i>affilate</a>
            <a href=""><i class="bx bx-chevron-right"></i>specials</a>
        </div>
        <div class="box">
            <h3>contact us</h3>
            <p><i class="bx bxs-phone"></i> 7265042553</p>
            <p><i class="bx bxs-envelope"></i> shekhaejaj445501@gmail.com</p>
            <p><i class="bx bxs-location-plus"></i> Middle Gujrat,India</p>
            <!-- <a href=""><i class="bxbx-chevron-right"></i>specials</a> -->
            <div class="icons">
                <a href="https://www.facebook.com/accounts/login/" target="_blank"><i class="bx bxl-facebook"></i></href></a>
                <br>
                <a href="https://www.instagram.com/accounts/login/" target="_blank"><i class="bx bxl-instagram"></i></a>
            </div>
        </div>
    </div>
    <div class="bottom">
        <p>Copy right &copy; 2024 by Aejaj.All Rights Reserved.</p>
        <a href="../adminpannel/login.php"> become a seller</a>
    </div>
</footer>